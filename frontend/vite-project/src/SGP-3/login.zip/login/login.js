document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    // Implement your login logic here
    console.log(`Username: ${username}, Password: ${password}, Role: ${role}`);
    
    // Dummy validation
    if (username === 'user' && password === 'pass' && (role === 'farmer' || role === 'customer')) {
        alert('Login successful!');
    } else {
        alert('Invalid credentials');
    }
});

document.getElementById('signupLink').addEventListener('click', function() {
    alert('Sign up functionality is not implemented.');
});

document.getElementById('forgotPasswordLink').addEventListener('click', function() {
    alert('Forgot password functionality is not implemented.');
});

document.getElementById('showPassword').addEventListener('change', function() {
    const passwordField = document.getElementById('password');
    if (this.checked) {
        passwordField.type = 'text';
    } else {
        passwordField.type = 'password';
    }
});
